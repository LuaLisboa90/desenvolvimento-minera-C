﻿using System;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace ProjetoFinal
{
    class Program
    {

        public static void Leitura(){
            String read;
            System.Console.WriteLine("Informe uma Palavra: ");
            read = Console.ReadLine();

            using (PdfReader reader = new PdfReader(@"\C:\Code\DataSet\Noticia7.pdf"))
            {
                var texto = new System.Text.StringBuilder();
                using StreamWriter file = new(@"\C:\Code\DataSet\teste31.txt", append: true);
                {
                    for (int i = 1; i < reader.NumberOfPages; i++)
                    {

                        String aux = PdfTextExtractor.GetTextFromPage(reader, i);
                        string[] linhas = aux.Split('\n');
                        foreach (string linha in linhas)
                        {
                            if (linha.Contains(read))
                            {
                                texto.Append($"{linha}{"\n"}");
                                file.WriteLine(linha);
                            }
                        }
                    }

                }
            }


        }


        static void Main(string[] args)
        {
            String pastaNome = @"C:\Code";

            string pathString = System.IO.Path.Combine(pastaNome, "Novas Palavras");
                
            System.IO.Directory.CreateDirectory(pathString);

            string nomeArquivo = "Teste1.txt";
        
            pathString = System.IO.Path.Combine(pathString, nomeArquivo);

            Console.WriteLine("Pressione a X para Entrar...");
            Console.ReadKey();
        
            if (!System.IO.File.Exists(pathString))
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(pathString))
                {
                    for (int i = 0; i < 100; i++)
                    {
                        file.Write($"{i} ");             
                    }
                }
            }
            else
            {
                Console.WriteLine("O arquivo \"{0}\" já existe.", nomeArquivo);            
            }
        
            try
            {
                foreach (string line in File.ReadLines(pathString))
                {
                    Console.WriteLine(line);
                }
            }
            catch (System.IO.IOException e)
            {
                Console.WriteLine(e.Message);
            }
            
            string[] lines = {"Linha 1", "Linha 2", "Linha 3"};

            nomeArquivo = "Teste3.txt";
            pathString = System.IO.Path.Combine(pastaNome, nomeArquivo);
        
            Leitura();

            Console.WriteLine("Pressione Qualquer tecla para sair");
            Console.ReadKey();


        }
    }
}
