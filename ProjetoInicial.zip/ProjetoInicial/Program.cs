﻿using System;

namespace ProjetoInicial
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Desenvolvimento de Aplicações e Mineração em C# ");
        }
    }
}
